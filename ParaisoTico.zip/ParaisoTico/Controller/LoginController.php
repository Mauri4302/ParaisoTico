<?php

    if (isset($_POST["btnIniciarSesion"])) {
        header('Location: ../View/Login/home.php');
    }
?>

