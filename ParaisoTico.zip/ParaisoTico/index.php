<?php
    header('location: View/Login/login.php');
?>